import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";
import utilDynamodb from "@aws-sdk/util-dynamodb";
const { marshallOptions, unmarshallOptions } = utilDynamodb;

// Initialize DynamoDB DocumentClient
const client = new DynamoDBClient({ region: "ca-central-1" });
const dynamoDB = DynamoDBDocumentClient.from(client, {
  marshallOptions,
  unmarshallOptions,
});

export const handler = async (event) => {
  try {
    // Parse and validate request body
    let body;
    try {
      body = JSON.parse(event.body);
    } catch (e) {
      return {
        statusCode: 400,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*", // Replace with your frontend domain
        },
        body: JSON.stringify({ error: "Invalid JSON in request body." }),
      };
    }

    const { serialKey, email } = body;

    // Validate inputs
    if (!serialKey?.trim() || !email?.trim()) {
      return {
        statusCode: 400,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({ error: "Serial key and email are required." }),
      };
    }

    // Validate email format
    const emailRegex = /^[^@]+@[^@]+\.[^@]+$/;
    if (!emailRegex.test(email)) {
      return {
        statusCode: 400,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({ error: "Invalid email format." }),
      };
    }

    // Query DynamoDB (assuming serialKey is the partition key)
    const params = {
      TableName: "CustomerTable",
      KeyConditionExpression: "serialKey = :serialKey",
      ExpressionAttributeValues: {
        ":serialKey": serialKey.trim(),
      },
    };

    const result = await dynamoDB.query(params);

    if (!result.Items || result.Items.length === 0) {
      return {
        statusCode: 400,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({ error: "Invalid serial key." }),
      };
    }

    if (result.Items.length > 1) {
      console.error("Multiple serial keys found for:", serialKey);
      return {
        statusCode: 400,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({ error: "Multiple serial keys found." }),
      };
    }

    const item = result.Items[0];

    // Validate ownerData
    let ownerData = [];
    try {
      ownerData = Array.isArray(item.ownerData)
        ? item.ownerData
        : JSON.parse(item.ownerData || "[]");
    } catch (e) {
      console.error("Failed to parse ownerData:", e.message);
      return {
        statusCode: 500,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({ error: "Invalid owner data format." }),
      };
    }

    // Validate email against ownerData
    const isAuthorized = ownerData.some(
      (owner) =>
        owner.email && owner.email.toLowerCase() === email.toLowerCase()
    );

    if (!isAuthorized) {
      return {
        statusCode: 403,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({
          error: "Email does not match the owner of this serial key.",
        }),
      };
    }

    // Generate fileKey (assuming fileKey is stored in DynamoDB or derived)
    const fileKey = item.fileKey || `F${serialKey.slice(1)}.zip`;

    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({ fileKey }),
    };
  } catch (error) {
    console.error("Error in verifySerialKey:", error.message);
    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({ error: "Internal server error." }),
    };
  }
};
